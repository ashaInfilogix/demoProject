<template>
  <div>
    <h1>User Profile</h1>
    <p>This is the user profile component.</p>
  </div>
</template>

<script>
export default {
  name: 'UserProfile'
}
</script>

<style scoped>
/* Add styles here if needed */
</style>
