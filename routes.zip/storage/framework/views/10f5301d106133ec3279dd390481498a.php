

<?php $__env->startSection('content'); ?>
    <section class="ftco-section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-6 text-center mb-5">
                    <h2 class="heading-section">Otp</h2>
                </div>
            </div>
            <div class="row justify-content-center">
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
                <div class="col-md-6 col-lg-4">
                    <div class="login-wrap p-0">
                        <form action="<?php echo e(route('verify-otp')); ?>" class="signin-form" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="email" value="<?php echo e($email); ?>">
                            <div class="form-group form-primary">
                                <input type="number" name="otp" id="otp" class="form-control" placeholder="OTP" required>
                                <span class="text-danger error-message" id="otp-error"></span>
                            </div>

                            <div class="form-group">
                                <button type="submit" class="form-control btn btn-primary submit px-3">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
   
    <script>
        $(function() {
            $("form").validate({
                rules: {
                    otp: {
                        
                        required: true,
                        otp: true // Email format validation
                    },
                },
                messages: {
                    otp: {
                        required: "Please enter your otp",
                        otp: "Please enter a valid otp"
                    },
                },
                errorClass: "text-danger f-12",
                errorElement: "span",
                errorPlacement: function(error, element) {
                    var errorId = "#" + element.attr("id") + "-error";
                    $(errorId).text(error.text());
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).parent().removeClass("form-primary").addClass("form-danger");
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).parent().removeClass("form-danger").addClass("form-primary");
                    var errorId = "#" + $(element).attr("id") + "-error";
                    $(errorId).text(""); // Clear the error message
                },
               
                submitHandler: function(form) {
                    form.submit();
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DemoProject\resources\views/auth/otp.blade.php ENDPATH**/ ?>